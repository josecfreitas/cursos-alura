const TiposCartao = {
    padrao: {nome: "Padrão", cor: "#EBEF40"}
    ,importante: {nome: "Importante", cor: "#F05450"}
    ,tarefa: {nome: "Tarefa", cor: "#92C4EC"}
    ,inspiracao: {nome: "Inspiração", cor: "#76EF40"}
}